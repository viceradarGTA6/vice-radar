import React, { useState, useMemo, useRef, useEffect } from "react";

const DATA = {
  items: [
    { id: "veh_001", tipo: "veicolo", nome: "Furgone Corazzato (esempio)", rarita: "raro", modalita: "online", descrizione: "Veicolo resistente con blindatura leggera, utile per missioni di trasporto.", come_ottenerlo: "Completare una serie di consegne senza danni al veicolo.", location_id: "loc_001", tags: ["corazzato", "lento", "resistente"] },
    { id: "arma_001", tipo: "arma", nome: "Fucile a Pompa Modificato (esempio)", rarita: "leggendario", modalita: "storia", descrizione: "Versione potenziata trovabile solo in un capitolo specifico.", come_ottenerlo: "Nascosta in un edificio abbandonato, richiede di esplorare fuori dai percorsi principali.", location_id: "loc_002", tags: ["capitolo 2", "danno alto"] },
    { id: "coll_001", tipo: "collezionabile", nome: "Statuetta Nascosta (esempio)", rarita: "unico", modalita: "entrambe", descrizione: "Una delle 20 statuette da collezionare sparse per la mappa.", come_ottenerlo: "Trovarla esplorando l'area costiera.", location_id: "loc_003", tags: ["collezione", "costa"] },
    { id: "veh_002", tipo: "veicolo", nome: "Moto d'Acqua Sportiva (esempio)", rarita: "comune", modalita: "entrambe", descrizione: "Veloce in acqua, ottima per fughe lungo la costa.", come_ottenerlo: "Disponibile presso il molo turistico.", location_id: "loc_004", tags: ["acqua", "veloce"] },
    { id: "arma_002", tipo: "arma", nome: "Pistola Silenziata (esempio)", rarita: "raro", modalita: "online", descrizione: "Ideale per approcci furtivi nelle missioni cooperative.", come_ottenerlo: "Ricompensa completando una rapina senza allarmi.", location_id: "loc_005", tags: ["furtivo"] },
  ],
  locations: [
    { id: "loc_001", nome: "Deposito Portuale (esempio)", x: 66, y: 40, categoria: "veicolo", item_id: "veh_001" },
    { id: "loc_002", nome: "Edificio Abbandonato (esempio)", x: 40, y: 24, categoria: "arma", item_id: "arma_001" },
    { id: "loc_003", nome: "Spiaggia Sud (esempio)", x: 27, y: 74, categoria: "collezionabile", item_id: "coll_001" },
    { id: "loc_004", nome: "Molo Turistico (esempio)", x: 78, y: 58, categoria: "veicolo", item_id: "veh_002" },
    { id: "loc_005", nome: "Vicolo Centrale (esempio)", x: 50, y: 46, categoria: "arma", item_id: "arma_002" },
  ],
  cheats: [
    { id: "cheat_001", nome_effetto: "Munizioni Infinite (esempio)", codice: "ESEMPIO-CODICE-01", piattaforma: "tutte", modalita: "storia", note: "Disattiva gli obiettivi mentre è attivo." },
    { id: "cheat_002", nome_effetto: "Salute Massima (esempio)", codice: "ESEMPIO-CODICE-02", piattaforma: "PC", modalita: "entrambe", note: "Nessuna limitazione nota." },
  ],
  missioni: [
    { id: "miss_001", nome: "Missione di Esempio", capitolo: 2, segreti_collegati: ["arma_001"], suggerimenti: "Esplora bene l'area prima di completare l'obiettivo principale, alcuni segreti diventano inaccessibili dopo." },
  ],
};

const CATS = [
  { key: "tutti", label: "Tutti", color: "#F2F0E9" },
  { key: "veicolo", label: "Veicoli", color: "#2DE3D6" },
  { key: "arma", label: "Armi", color: "#FF3D8A" },
  { key: "collezionabile", label: "Collez.", color: "#FFC24B" },
];
const catColor = (cat) => CATS.find((c) => c.key === cat)?.color || "#F2F0E9";

/* piccole icone decorative "città" per arredare la mappa */
function CityIcon({ kind, size = 18, color = "#E9E4D8" }) {
  if (kind === "aeroporto") return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M2 16l8-2.5V6a1.5 1.5 0 013 0v7.5L21 16v2l-8-1.5V20l2.5 1.5V23l-4-1-4 1v-1.5L12 20v-3.5L2 18v-2z" fill={color} />
    </svg>
  );
  if (kind === "stadio") return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <ellipse cx="12" cy="12" rx="10" ry="7" stroke={color} strokeWidth="1.8" fill="none" />
      <ellipse cx="12" cy="12" rx="6" ry="3.5" stroke={color} strokeWidth="1.4" fill="none" />
    </svg>
  );
  if (kind === "porto") return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M4 14h16l-2 6H6l-2-6z" fill={color} />
      <path d="M12 3v11M8 6l4-3 4 3" stroke={color} strokeWidth="1.6" fill="none" />
    </svg>
  );
  return null;
}

function PalmSilhouette({ style }) {
  return (
    <svg viewBox="0 0 100 140" width="60" height="86" style={style}>
      <path d="M50 140 L50 60" stroke="#241a3d" strokeWidth="5" fill="none" />
      <g fill="#241a3d">
        <path d="M50 60 C20 45 5 55 0 40 C25 40 40 50 50 60Z" />
        <path d="M50 60 C80 45 95 55 100 40 C75 40 60 50 50 60Z" />
        <path d="M50 60 C35 30 25 20 30 5 C45 20 48 40 50 60Z" />
        <path d="M50 60 C65 30 75 20 70 5 C55 20 52 40 50 60Z" />
        <path d="M50 60 C50 25 50 15 50 0 C50 25 50 45 50 60Z" />
      </g>
    </svg>
  );
}

function searchAll(query) {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const results = [];
  DATA.items.forEach((it) => {
    const hay = [it.nome, ...(it.tags || [])].join(" ").toLowerCase();
    if (hay.includes(q)) results.push({ kind: "item", id: it.id, label: it.nome, sub: it.tipo });
  });
  DATA.cheats.forEach((c) => { if (c.nome_effetto.toLowerCase().includes(q)) results.push({ kind: "cheat", id: c.id, label: c.nome_effetto, sub: "trucco" }); });
  DATA.missioni.forEach((m) => { if (m.nome.toLowerCase().includes(q)) results.push({ kind: "missione", id: m.id, label: m.nome, sub: "missione" }); });
  return results.slice(0, 8);
}

function useIsMobile() {
  const [isMobile, setIsMobile] = useState(typeof window !== "undefined" ? window.innerWidth < 820 : false);
  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 820);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  return isMobile;
}

/* ---------- Contenuto dettagli (riusato sia nella scheda overlay che nel pannello desktop) ---------- */
function DetailContent({ selected, onAskAI }) {
  const selectedItem = selected ? DATA.items.find((i) => i.id === selected.item_id) : null;
  const relatedMissions = selectedItem ? DATA.missioni.filter((m) => m.segreti_collegati?.includes(selectedItem.id)) : [];
  if (!selectedItem) {
    return <div style={{ color: "#9AA0C0", fontSize: 14, lineHeight: 1.6 }}>Tocca un punto sulla mappa per vedere dove si trova, come raggiungerlo e come ottenerlo.</div>;
  }
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <div style={{ width: 14, height: 14, borderRadius: "50%", background: catColor(selected.categoria), flexShrink: 0 }} />
        <div style={{ fontSize: 10, letterSpacing: 2, color: catColor(selected.categoria), fontWeight: 700 }}>
          {selectedItem.tipo.toUpperCase()} · {selectedItem.rarita.toUpperCase()}
        </div>
      </div>
      <div style={{ fontSize: 19, fontWeight: 800, marginBottom: 10 }}>{selectedItem.nome}</div>
      <div style={{ fontSize: 13, color: "#C7CBDA", marginBottom: 12, lineHeight: 1.5 }}>{selectedItem.descrizione}</div>
      <div style={{ fontSize: 11, letterSpacing: 1, color: "#7A8099", marginBottom: 4 }}>COME RAGGIUNGERLO / OTTENERLO</div>
      <div style={{ fontSize: 13, lineHeight: 1.5, marginBottom: 12 }}>{selectedItem.come_ottenerlo}</div>
      {relatedMissions.length > 0 && (
        <>
          <div style={{ fontSize: 11, letterSpacing: 1, color: "#7A8099", marginBottom: 4 }}>MISSIONE COLLEGATA</div>
          {relatedMissions.map((m) => (
            <div key={m.id} style={{ fontSize: 13, marginBottom: 12, lineHeight: 1.5 }}>
              <strong>{m.nome}</strong> (cap. {m.capitolo}) — {m.suggerimenti}
            </div>
          ))}
        </>
      )}
      <div style={{ fontSize: 11, letterSpacing: 1, color: "#7A8099", marginBottom: 12 }}>MODALITÀ: {selectedItem.modalita.toUpperCase()}</div>
      <button
        onClick={() => onAskAI(`Come faccio a ottenere: ${selectedItem.nome}?`)}
        style={{ width: "100%", background: "transparent", border: "1px solid #2DE3D6", color: "#2DE3D6", borderRadius: 6, padding: "12px 10px", fontSize: 13, fontWeight: 700, cursor: "pointer" }}
      >
        Chiedi all'assistente →
      </button>
    </div>
  );
}

/* ---------- Assistente IA ---------- */
function AIAssistant({ prefill, onConsumePrefill }) {
  const [messages, setMessages] = useState([
    { role: "assistant", text: "Ciao! Chiedimi come raggiungere un punto, completare una missione o quale trucco usare. Rispondo in base ai dati dimostrativi già caricati nel sito." },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => { if (prefill) { setInput(prefill); onConsumePrefill(); } }, [prefill]);
  useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight }); }, [messages, loading]);

  async function send(question) {
    const text = (question ?? input).trim();
    if (!text || loading) return;
    const newMessages = [...messages, { role: "user", text }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);
    const systemPrompt = `Sei l'assistente del sito guida di GTA6. Rispondi SOLO in italiano, breve e pratico, come un giocatore esperto.
Usa ESCLUSIVAMENTE queste informazioni (dati dimostrativi, il gioco non è ancora uscito):
${JSON.stringify(DATA)}
Se la domanda riguarda qualcosa non presente nei dati, spiega che è un dato di esempio e che l'informazione reale arriverà all'uscita del gioco.`;
    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: systemPrompt,
          messages: newMessages.map((m) => ({ role: m.role === "assistant" ? "assistant" : "user", content: m.text })),
        }),
      });
      const data = await response.json();
      const reply = data?.content?.find((c) => c.type === "text")?.text || "Non sono riuscito a generare una risposta, riprova.";
      setMessages((prev) => [...prev, { role: "assistant", text: reply }]);
    } catch (e) {
      setMessages((prev) => [...prev, { role: "assistant", text: "Errore di connessione, riprova tra poco." }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 10, paddingRight: 2, marginBottom: 10 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ alignSelf: m.role === "user" ? "flex-end" : "flex-start", maxWidth: "88%", background: m.role === "user" ? "#26305a" : "#16233f", border: `1px solid ${m.role === "user" ? "#2DE3D6" : "#1C2340"}`, borderRadius: 10, padding: "10px 13px", fontSize: 14, lineHeight: 1.5, whiteSpace: "pre-wrap" }}>
            {m.text}
          </div>
        ))}
        {loading && <div style={{ fontSize: 12, color: "#7A8099" }}>L'assistente sta scrivendo…</div>}
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder="Scrivi una domanda…"
          style={{ flex: 1, background: "#0F1530", border: "1px solid #1C2340", borderRadius: 8, padding: "12px 14px", color: "#F2F0E9", fontSize: 15, outline: "none" }}
        />
        <button onClick={() => send()} disabled={loading} style={{ background: "#FF3D8A", border: "none", borderRadius: 8, padding: "0 18px", color: "#0B1026", fontWeight: 800, fontSize: 13, cursor: loading ? "default" : "pointer", opacity: loading ? 0.6 : 1 }}>
          Invia
        </button>
      </div>
    </div>
  );
}

/* ---------- Mappa illustrata stile gioco ---------- */
function MapCanvas({ locations, selected, onSelect, height }) {
  return (
    <div style={{ position: "relative", width: "100%", height, minHeight: 380, borderRadius: 10, overflow: "hidden", border: "1px solid #2a2350" }}>
      <svg viewBox="0 0 100 100" width="100%" height="100%" preserveAspectRatio="xMidYMid slice" style={{ position: "absolute", inset: 0 }}>
        <defs>
          <linearGradient id="water" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#1c3d5e" />
            <stop offset="100%" stopColor="#0e2038" />
          </linearGradient>
          <linearGradient id="land" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#d9c98f" />
            <stop offset="100%" stopColor="#c3ae72" />
          </linearGradient>
          <clipPath id="landClip">
            <path d="M18,20 C10,30 8,45 14,58 C18,68 16,80 26,88 C40,96 58,94 66,84 C72,76 68,68 76,60 C86,50 88,36 78,24 C68,12 50,8 38,10 C28,12 24,14 18,20 Z" />
          </clipPath>
        </defs>

        {/* acqua di sfondo */}
        <rect x="0" y="0" width="100" height="100" fill="url(#water)" />
        {/* riflessi acqua */}
        {Array.from({ length: 14 }).map((_, i) => (
          <line key={"wave" + i} x1={Math.random() * 100} y1={Math.random() * 100} x2={Math.random() * 100 + 3} y2={Math.random() * 100} stroke="#3a6a8f" strokeWidth="0.3" opacity="0.5" />
        ))}

        {/* terraferma */}
        <path d="M18,20 C10,30 8,45 14,58 C18,68 16,80 26,88 C40,96 58,94 66,84 C72,76 68,68 76,60 C86,50 88,36 78,24 C68,12 50,8 38,10 C28,12 24,14 18,20 Z" fill="url(#land)" stroke="#8f7a3f" strokeWidth="0.4" />

        {/* griglia stradale, clippata sulla terraferma */}
        <g clipPath="url(#landClip)" opacity="0.55">
          {Array.from({ length: 20 }).map((_, i) => (
            <line key={"sv" + i} x1={i * 5} y1="0" x2={i * 5} y2="100" stroke="#8a7540" strokeWidth="0.35" />
          ))}
          {Array.from({ length: 20 }).map((_, i) => (
            <line key={"sh" + i} x1="0" y1={i * 5} x2="100" y2={i * 5} stroke="#8a7540" strokeWidth="0.35" />
          ))}
          {/* isolati/edifici */}
          {Array.from({ length: 26 }).map((_, i) => {
            const bx = 12 + (i % 7) * 9 + (Math.random() * 2 - 1);
            const by = 14 + Math.floor(i / 7) * 11 + (Math.random() * 2 - 1);
            return <rect key={"b" + i} x={bx} y={by} width={4 + Math.random() * 2} height={4 + Math.random() * 2} fill="#a68f52" opacity="0.6" />;
          })}
          {/* svincoli/autostrade più marcate */}
          <path d="M12,50 C30,45 50,55 88,48" stroke="#5b4a24" strokeWidth="1.1" fill="none" opacity="0.8" />
          <path d="M35,10 C40,35 42,60 40,92" stroke="#5b4a24" strokeWidth="1.1" fill="none" opacity="0.8" />
        </g>

        {/* bordo costa evidenziato */}
        <path d="M18,20 C10,30 8,45 14,58 C18,68 16,80 26,88 C40,96 58,94 66,84 C72,76 68,68 76,60 C86,50 88,36 78,24 C68,12 50,8 38,10 C28,12 24,14 18,20 Z" fill="none" stroke="#FFC24B" strokeWidth="0.5" opacity="0.6" />
      </svg>

      {/* etichette quartieri (fittizie) */}
      {[
        { label: "Distretto Nord (esempio)", x: 42, y: 16 },
        { label: "Centro (esempio)", x: 48, y: 46 },
        { label: "Zona Costiera Sud (esempio)", x: 26, y: 78 },
        { label: "Area Portuale (esempio)", x: 70, y: 42 },
      ].map((d) => (
        <div key={d.label} style={{ position: "absolute", left: `${d.x}%`, top: `${d.y}%`, transform: "translate(-50%,-50%)", fontSize: 9, letterSpacing: 1, color: "#3a2f14", fontWeight: 700, textTransform: "uppercase", pointerEvents: "none", textShadow: "0 1px 0 rgba(255,255,255,0.25)" }}>
          {d.label}
        </div>
      ))}

      {/* icone decorative città */}
      <div style={{ position: "absolute", left: "70%", top: "20%" }}><CityIcon kind="aeroporto" color="#3a2f14" /></div>
      <div style={{ position: "absolute", left: "52%", top: "58%" }}><CityIcon kind="stadio" color="#3a2f14" /></div>
      <div style={{ position: "absolute", left: "80%", top: "50%" }}><CityIcon kind="porto" color="#3a2f14" /></div>

      <PalmSilhouette style={{ position: "absolute", left: "2%", bottom: "2%", opacity: 0.85 }} />
      <PalmSilhouette style={{ position: "absolute", right: "3%", top: "4%", opacity: 0.6, transform: "scale(0.6)" }} />

      {/* marker */}
      {locations.map((loc) => {
        const color = catColor(loc.categoria);
        const isSel = selected?.id === loc.id;
        return (
          <button
            key={loc.id}
            onClick={() => onSelect(loc)}
            title={loc.nome}
            style={{
              position: "absolute", left: `${loc.x}%`, top: `${loc.y}%`,
              transform: "translate(-50%, -50%)",
              width: isSel ? 22 : 16, height: isSel ? 22 : 16,
              borderRadius: "50%",
              background: color,
              border: isSel ? "2.5px solid #F2F0E9" : "1.5px solid rgba(11,16,38,0.5)",
              boxShadow: `0 0 ${isSel ? 16 : 9}px ${color}`,
              cursor: "pointer", padding: 0,
            }}
          />
        );
      })}
    </div>
  );
}

/* ---------- App principale ---------- */
export default function GTA6Map() {
  const isMobile = useIsMobile();
  const [filter, setFilter] = useState("tutti");
  const [selected, setSelected] = useState(null);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("mappa"); // "mappa" | "assistente"
  const [prefill, setPrefill] = useState("");

  const locations = useMemo(() => (filter === "tutti" ? DATA.locations : DATA.locations.filter((l) => l.categoria === filter)), [filter]);
  const results = useMemo(() => searchAll(query), [query]);

  function pickResult(r) {
    setQuery("");
    if (r.kind === "item") {
      const loc = DATA.locations.find((l) => l.item_id === r.id);
      if (loc) { setSelected(loc); setFilter("tutti"); setTab("mappa"); }
    } else if (r.kind === "cheat") {
      const cheat = DATA.cheats.find((c) => c.id === r.id);
      setTab("assistente");
      setPrefill(`Parlami del trucco: ${cheat.nome_effetto}`);
    } else if (r.kind === "missione") {
      const m = DATA.missioni.find((mm) => mm.id === r.id);
      setTab("assistente");
      setPrefill(`Come supero la missione: ${m.nome}?`);
    }
  }

  return (
    <div style={{ minHeight: "100vh", width: "100%", background: "#0B1026", color: "#F2F0E9", fontFamily: "'Arial Narrow', 'Helvetica Neue', Arial, sans-serif", display: "flex", flexDirection: "column", paddingBottom: isMobile ? 62 : 0 }}>
      {/* Header */}
      <div style={{ padding: isMobile ? "14px 14px 10px" : "18px 24px", borderBottom: "2px solid #2DE3D6" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10, marginBottom: 10 }}>
          <span style={{ fontWeight: 900, fontSize: isMobile ? 22 : "clamp(20px, 4vw, 30px)", letterSpacing: "1.5px", background: "linear-gradient(90deg,#FF3D8A,#FFC24B,#2DE3D6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", textTransform: "uppercase" }}>
            Leonida // Radar
          </span>
          {!isMobile && <span style={{ fontSize: 11, letterSpacing: 2, color: "#2DE3D6" }}>{locations.length} PUNTI ATTIVI</span>}
        </div>

        <div style={{ position: "relative" }}>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Cerca oggetti, trucchi, missioni…"
            style={{ width: "100%", background: "#0F1530", border: "1px solid #1C2340", borderRadius: 8, padding: isMobile ? "12px 14px" : "9px 12px", color: "#F2F0E9", fontSize: isMobile ? 15 : 13, outline: "none", boxSizing: "border-box" }}
          />
          {results.length > 0 && (
            <div style={{ position: "absolute", top: "110%", left: 0, right: 0, background: "#0F1530", border: "1px solid #1C2340", borderRadius: 8, overflow: "hidden", zIndex: 20 }}>
              {results.map((r) => (
                <div key={r.kind + r.id} onClick={() => pickResult(r)} style={{ padding: "12px 14px", fontSize: 14, cursor: "pointer", borderBottom: "1px solid #1C2340" }}>
                  <span style={{ color: "#7A8099" }}>[{r.sub}]</span> {r.label}
                </div>
              ))}
            </div>
          )}
        </div>

        <div style={{ display: "flex", gap: 8, marginTop: 12, overflowX: isMobile ? "auto" : "visible", paddingBottom: 2 }}>
          {CATS.map((c) => (
            <button
              key={c.key}
              onClick={() => { setFilter(c.key); }}
              style={{
                display: "flex", alignItems: "center", gap: 6, flexShrink: 0,
                background: filter === c.key ? c.color : "transparent",
                color: filter === c.key ? "#0B1026" : c.color,
                border: `1px solid ${c.color}`, borderRadius: 20,
                padding: isMobile ? "8px 14px" : "6px 14px",
                fontSize: 12, fontWeight: 700, letterSpacing: 0.5, cursor: "pointer", whiteSpace: "nowrap",
              }}
            >
              {c.key !== "tutti" && <span style={{ width: 8, height: 8, borderRadius: "50%", background: filter === c.key ? "#0B1026" : c.color, flexShrink: 0 }} />}
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Contenuto */}
      {isMobile ? (
        <div style={{ padding: 14, flex: 1 }}>
          {tab === "mappa" && (
            <div style={{ position: "relative" }}>
              <MapCanvas locations={locations} selected={selected} onSelect={setSelected} height="62vh" />
              {/* scheda overlay: la mappa resta visibile dietro */}
              {selected && (
                <div
                  style={{
                    position: "absolute", left: 0, right: 0, bottom: 0,
                    maxHeight: "58%", overflowY: "auto",
                    background: "#0F1530", borderTop: "2px solid #2DE3D6",
                    borderRadius: "14px 14px 0 0",
                    padding: "14px 16px 18px",
                    boxShadow: "0 -8px 24px rgba(0,0,0,0.4)",
                  }}
                >
                  <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 4 }}>
                    <button onClick={() => setSelected(null)} style={{ background: "none", border: "none", color: "#7A8099", fontSize: 20, cursor: "pointer", lineHeight: 1 }}>×</button>
                  </div>
                  <DetailContent selected={selected} onAskAI={(q) => { setTab("assistente"); setPrefill(q); }} />
                </div>
              )}
            </div>
          )}
          {tab === "assistente" && (
            <div style={{ background: "#0F1530", border: "1px solid #1C2340", borderRadius: 10, padding: 16, height: "70vh" }}>
              <AIAssistant prefill={prefill} onConsumePrefill={() => setPrefill("")} />
            </div>
          )}
        </div>
      ) : (
        <div style={{ display: "flex", flex: 1, flexDirection: "row", flexWrap: "wrap" }}>
          <div style={{ flex: "1 1 600px", margin: 20, position: "relative" }}>
            <MapCanvas locations={locations} selected={selected} onSelect={setSelected} height="calc(100vh - 220px)" />
          </div>
          <div style={{ flex: "0 1 340px", margin: "20px 20px 20px 0", padding: 18, border: "1px solid #1C2340", borderRadius: 10, background: "#0F1530", minHeight: 480, display: "flex", flexDirection: "column" }}>
            <div style={{ display: "flex", gap: 6, marginBottom: 14 }}>
              {["dettagli", "assistente"].map((k) => (
                <button
                  key={k}
                  onClick={() => setTab(k)}
                  style={{ flex: 1, background: tab === k ? "#FF3D8A" : "transparent", color: tab === k ? "#0B1026" : "#F2F0E9", border: "1px solid #1C2340", borderRadius: 6, padding: "8px 0", fontSize: 11, fontWeight: 800, letterSpacing: 1, cursor: "pointer", textTransform: "uppercase" }}
                >
                  {k === "dettagli" ? "Dettagli" : "Assistente IA"}
                </button>
              ))}
            </div>
            <div style={{ flex: 1, minHeight: 0 }}>
              {tab === "assistente" ? (
                <AIAssistant prefill={prefill} onConsumePrefill={() => setPrefill("")} />
              ) : (
                <DetailContent selected={selected} onAskAI={(q) => { setTab("assistente"); setPrefill(q); }} />
              )}
            </div>
          </div>
        </div>
      )}

      {/* Bottom nav mobile: solo Mappa / Assistente */}
      {isMobile && (
        <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, display: "flex", background: "#0F1530", borderTop: "1px solid #1C2340", zIndex: 30 }}>
          {[{ key: "mappa", label: "Mappa" }, { key: "assistente", label: "Assistente" }].map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              style={{ flex: 1, background: "none", border: "none", padding: "12px 0", color: tab === t.key ? "#2DE3D6" : "#7A8099", fontWeight: tab === t.key ? 800 : 600, fontSize: 12, letterSpacing: 0.5, cursor: "pointer" }}
            >
              {t.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
